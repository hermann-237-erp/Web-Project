package praktikumWeb.jdbc;

public class PostgreSQLAccess extends JDBCAccess {

	public PostgreSQLAccess() throws NoConnectionException {
		super();
	}

	public void setDBParms() {
		dbDrivername = "org.postgresql.Driver";
		dbURL = "jdbc:postgresql://143.93.200.243:5435/BWUEBDB";
		dbUser = "user1";
		dbPassword = "pgusers";
//		dbURL        = "jdbc:postgresql://localhost:5432/BWUEBDB";
//		dbUser       = "pgadmin";
//		dbPassword   = "pgadmin";
		dbSchema = "bwi420_chc2"; // hier Matrikelnummer eintragen
//		dbSchema = "bwi420_636892";

	}

	public static void main(String[] args) throws NoConnectionException {
		new PostgreSQLAccess().getConnection();
	}
}