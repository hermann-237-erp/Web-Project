package praktikumWeb.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

public class AppInstallTables {

	Connection dbConn;
	
	
	public static void main(String[] args) throws SQLException {
		AppInstallTables myApp = new AppInstallTables();
		myApp.dbConn = new PostgreSQLAccess().getConnection();
	myApp.doSomething();
}

	public void doSomething() throws SQLException {
		
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS ANGEBOT");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS bestart");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS rechnung");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS BENUTZER");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS Bestellung");
		this.executeUpdateWithoutParms("DROP TABLE IF EXISTS Artikel");
		this.createTableBENUTZER();
		this.createTableAngebot();
		this.createTableBestArt();
		this.createTableRechnung();
		
	}
	public void executeUpdateWithoutParms(String sql) throws SQLException{
		System.out.println(sql);
		this.dbConn.prepareStatement(sql).executeUpdate();
	}
	public void createTableBENUTZER() throws SQLException {
		this.executeUpdateWithoutParms(
			"CREATE TABLE BENUTZER(" + 
				"user_id serial               ," + 
				"vorname               VARCHAR (25)      ," + 
				"nachname              VARCHAR(50)	 	 ," +
				"passwort              VARCHAR(50)	 	 ," +
				"email      VARCHAR (50)     PRIMARY KEY ," +
				"straße                VARCHAR (50)     ," + 
				"haus_nr               INT               ," +
				"plz                   INT               ," +
				"stadt                 VARCHAR (50)      ," + 
				"telefonnummer         VARCHAR (50)      ," + 
				"geburtsdatum          VARCHAR (50)      ," + 
	//			"alter                 INT               ," +
				"userfoto            VARCHAR(255)       " + 
				
			")"
		);		
	}
	public void createTableAngebot() throws SQLException {
		this.executeUpdateWithoutParms(
			"CREATE TABLE ANGEBOT(" + 
				"angebot_id             SERIAL      PRIMARY KEY," +
				"titel_des_angebots     TEXT                   ," + 
				"rubrik                 VARCHAR(50)            ," + 
				"stadt                  VARCHAR(50)            ," + 
				"strasse_Nr             VARCHAR(50)            ," +
				"postleitzahl_Stadt     VARCHAR(50)            ," + 
				"stadtteil              VARCHAR(50)            ," + 
				"verfuegbar_ab          VARCHAR(255)           ," + 
				"verfuegbar_bis         VARCHAR(255)           ," + 
				"etage			         VARCHAR(255)          ," + 
				"beschreibung           TEXT                   ," + 
				"zimmergroesse          VARCHAR(50)            ," +
				"kaution                VARCHAR(50)            ," + 
				"wohnungsgroesse        VARCHAR(50)            ," + 
				"kaltmiete              VARCHAR(50)            ," + 
				"nebenkosten            VARCHAR(50)            ," + 
				"gesamtmiete            VARCHAR(50)            ," +
				"zimmer_anzahl          VARCHAR(50)            ," + 
				"sprache                VARCHAR(100)           ," +
				"ausstattung            VARCHAR(255)           ," + 
				"gesuche_geschlecht     VARCHAR(50)            ," + 
				"vermirter_email VARCHAR(50)  REFERENCES BENUTZER (email) ," + 
				"zimmerfoto             VARCHAR(255)           ," + 
				"angeleget_am    DATE         DEFAULT CURRENT_DATE " + 
			")"
		);		
	}
	public void createTableBestArt() throws SQLException {
		this.executeUpdateWithoutParms(
			"CREATE TABLE BESTART(" + 
				"ANR      INTEGER      NOT NULL            ," + 
				"BNR      INTEGER      NOT NULL            ," + 
				"PRIMARY KEY(ANR, BNR)" + 
			")"
		);		
	}
	public void createTableRechnung() throws SQLException {
		this.executeUpdateWithoutParms(
			"CREATE TABLE RECHNUNG(" + 
				"RNR      SERIAL       NOT NULL PRIMARY KEY," + 
				"KUNDE    VARCHAR(128) NOT NULL            ," + 
				"ARTIKEL  TEXT         NOT NULL" + 
			")"
		);		
	}
	
	
}
