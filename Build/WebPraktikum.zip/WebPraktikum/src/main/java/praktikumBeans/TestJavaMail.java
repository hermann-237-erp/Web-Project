package praktikumBeans;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class TestJavaMail {


    private static final String API_KEY = "YOUR_API_KEY";
    private static final String API_URL = "https://api.emailverifier.com/verify?email=";

    public static boolean verifyEmail(String email) {
        try {
            URL url = new URL(API_URL + email + "&apiKey=" + API_KEY);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            int responseCode = conn.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                // Parse the JSON response here to determine if the email is valid
                String responseBody = response.toString();
                System.out.println("Response from API: " + responseBody);

                // Suppose the API returns a JSON object with a field "valid"
                // if (responseBody.contains("\"valid\":true")) {
                //     return true;
                // }

                return true; // Placeholder
            } else {
                System.out.println("API response code: " + responseCode);
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        boolean isValid = verifyEmail("nganouchristian@gmail.com");
        if (isValid) {
            System.out.println("L'adresse e-mail est valide.");
        } else {
            System.out.println("L'adresse e-mail est invalide.");
        }
    }

}

