package praktikumBeans;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import praktikumWeb.jdbc.NoConnectionException;
import praktikumWeb.jdbc.PostgreSQLAccess;

public class AccountBean {

	String vorname;
	String nachname;
	String email;
	String telefonnummer;
	String strasse;
	int haus_nr;
	String stadt;
	int plz;
	String geburtsdatum;
	String passwort;
	boolean angemeldet;
	String BestaetigungsCode;

	public AccountBean() {
		 vorname = "";
		 nachname = "";
		 email = "";
		 telefonnummer = "";
		 strasse = "";
		 haus_nr = 0;
		 stadt = "";
		 plz = 0;
		 geburtsdatum = "";
		 passwort ="";
		 angemeldet= false;
		 BestaetigungsCode ="";
	}

	
	public boolean checkEmailExists() throws SQLException{
		String sql = "select email from BENUTZER where email = ?";
		System.out.println(sql);
		PreparedStatement prep = new PostgreSQLAccess().getConnection().prepareStatement(sql);
		prep.setString(1,  this.email);
		ResultSet dbRes = prep.executeQuery();
		if (dbRes.next()) {
			System.out.println("Account " + this.email + " existiert");
			return true;
		}
		return dbRes.next();
	}
	
	public void insertAccount() throws NoConnectionException, SQLException{
		String sql = "INSERT INTO BENUTZER "
		           + "(vorname, nachname, email, passwort, telefonnummer, straße, haus_nr, stadt, plz, geburtsdatum) "
		           + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

		System.out.println(sql);
		PreparedStatement prep = new PostgreSQLAccess().
				getConnection().
				prepareStatement(sql);
		prep.setString(1, this.vorname);
		prep.setString(2, this.nachname);
		prep.setString(3, this.email);
		prep.setString(4, this.passwort);
		prep.setString(5, this.telefonnummer);
		prep.setString(6, this.strasse);
		prep.setInt(7, this.haus_nr);
		prep.setString(8, this.stadt);
		prep.setInt(9, this.plz);
		prep.setString(10, this.geburtsdatum);
		prep.executeUpdate();
		System.out.println("Account erfolgreich angelegt");
	}
	
	
	
	public boolean checkEmailPassword() throws NoConnectionException, SQLException {
		String sql = "SELECT email from BENUTZER where email = ? and passwort = ?";
		System.out.println(sql);
		PreparedStatement prep = new PostgreSQLAccess().getConnection().prepareStatement(sql);
		prep.setString(1, this.email);
		prep.setString(2, this.passwort);
		ResultSet dbRes = prep.executeQuery();
		return dbRes.next();
	}
	
	public String getPersönlichenDaten() throws SQLException {
		String html = "";
		if (isAngemeldet()) {
		String sql = "SELECT * from BENUTZER where email = ?";
		System.out.println(sql);
		PreparedStatement prep = new PostgreSQLAccess().getConnection().prepareStatement(sql);
		prep.setString(1, this.email);
		ResultSet dbRes = prep.executeQuery();
		while (dbRes.next()) {
			html += " <div class=\"form-group\">\r\n"
					+ "                    <label for=\"vorname\">Vorname:</label>\r\n"
					+ "                    "+dbRes.getString("vorname")+"\r\n"
					+ "                </div>\r\n"
					+ "\r\n"
					+ "                <div class=\"form-group\">\r\n"
					+ "                    <label for=\"nachname\">Nachname:</label>\r\n"
					+ "                    "+dbRes.getString("nachname")+"\r\n"
					+ "                </div>\r\n"
					+ "\r\n"
					+ "                <div class=\"form-group\">\r\n"
					+ "                    <label for=\"email\">E-Mail:</label>\r\n"
					+ "                    "+dbRes.getString("email")+"\r\n"
					+ "                </div>\r\n"
					+ "\r\n"
					+ "                <div class=\"form-group\">\r\n"
					+ "                    <label for=\"telefonnummer\">Telefonnummer:</label>\r\n"
					+ "                   "+dbRes.getString("telefonnummer")+"\r\n"
					+ "                </div>\r\n"
					+ "\r\n"
					+ "                <!-- Gruppe für Straße und Hausnummer -->\r\n"
					+ "                <div class=\"form-row\">\r\n"
					+ "                    <div class=\"form-group\">\r\n"
					+ "                        <label for=\"strasse\">Straße:</label>\r\n"
					+ "                       "+dbRes.getString("straße")+"\r\n"
					+ "                    </div>\r\n"
					+ "                    <div class=\"form-group\">\r\n"
					+ "                        <label for=\"haus_nr\">Hausnummer:</label>\r\n"
					+ "                       "+dbRes.getInt("haus_nr")+"\r\n"
					+ "                    </div>\r\n"
					+ "                </div>\r\n"
					+ "\r\n"
					+ "                <!-- Gruppe für Stadt und PLZ -->\r\n"
					+ "                <div class=\"form-row\">\r\n"
					+ "                    <div class=\"form-group\">\r\n"
					+ "                        <label for=\"stadt\">Stadt:</label>\r\n"
					+ "                      "+dbRes.getString("stadt")+"\r\n"
					+ "                    </div>\r\n"
					+ "                    <div class=\"form-group\">\r\n"
					+ "                        <label for=\"plz\">PLZ:</label>\r\n"
					+ "                      "+dbRes.getInt("plz")+"\r\n"
					+ "                    </div>\r\n"
					+ "                </div>\r\n"
					+ "\r\n"
					+ "                <div class=\"form-group\">\r\n"
					+ "                    <label for=\"geburtsdatum\">Geburtsdatum:</label>\r\n"
					+ "                  "+dbRes.getString("geburtsdatum")+"\r\n"
					+ "                </div>\r\n"
					+ "  \r\n"
					+ "  				<div class=\"form-group\">\r\n"
					+ "                    <label for=\"passwort\">password:</label>\r\n"
					+ "                    "+dbRes.getString("passwort")+"\r\n"
					+ "                </div>";
	}
	return html;
		}
		else return html;	
	}
		
	public void persönlicheDatenUpdate(String vorname, String nachname, String email, String telefonnumer, 
			String strasse, int hs_nr,String stadt, int plz, String passwort ) throws SQLException {
		int index = 0; 
		String sql ="UPDATE benutzer set ";
		List<String> values = new ArrayList<>();
		if (vorname != "")
				values.add("vorname");
		if (nachname != "")
			values.add("nachname");
		if (email != "")
			values.add("email");
		if (telefonnumer != "")
			values.add("telefonnummer");
		if (strasse != "")
			values.add("straße");
		if (hs_nr != 0)
			values.add("haus_nr");
		if (stadt != "")
			values.add("stadt");
		if (plz != 0)
			values.add("plz");
		if (passwort != "")
			values.add("passwort");
		
		for(String value: values) {
			index++;
			sql += ""+value+ " = ?";
			if (index < values.size())
				sql +=" , ";
		}
		sql += " WHERE email = ?";
			System.out.println(sql);
			PreparedStatement prep = new PostgreSQLAccess()
			        .getConnection()
			        .prepareStatement(sql);
			for(String value: values) {
				if (value == "vorname")
					prep.setString(values.indexOf("vorname")+1, vorname);
				if (value == "nachname")
					prep.setString(values.indexOf("nachname")+1, nachname);
				if (value == "email")
					prep.setString(values.indexOf("email")+1, email);
				if (value == "telefonnummer")
					prep.setString(values.indexOf("telefonnummer")+1, telefonnumer);
				if (value == "straße")
					prep.setString(values.indexOf("straße")+1, strasse);
				if (value == "haus_nr")
					prep.setInt(values.indexOf("haus_nr")+1, hs_nr);
				if (value == "stadt")
					prep.setString(values.indexOf("stadt")+1, stadt);
				if (value == "plz")
					prep.setInt(values.indexOf("plz")+1, plz);
				if (value == "passwort")
					prep.setString(values.indexOf("passwort")+1, passwort);
				}
		 
			prep.setString(values.size()+1, this.email);
			prep.executeUpdate();
	}
	
		
	
	
	public boolean sendBestaetigungsCode(String Empfaenger, String Betreff, String Handlung ) {
		String chars = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder result = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < 10; i++) {
            int index = random.nextInt(chars.length());
            result.append(chars.charAt(index));
        }
        
        BestaetigungsCode = result.toString();
		
		JavaMail javaMail = new JavaMail();
		javaMail.setEmpfaenger(Empfaenger);
		javaMail.setBetreff(Betreff);
		//javaMail.setNachricht("Klicken Sie auf den folgenden Link, um Ihr Passwort zurückzusetzen: " + resetLink);
		javaMail.setNachricht("Bitte geben diesen Code: "+BestaetigungsCode+" zur " +Handlung+" ein ");

		return javaMail.sendEmail();
	}

	public void passwordupdate(String passwort) throws NoConnectionException, SQLException {
	
		String sql = "UPDATE benutzer "
				+ "SET passwort = ? "
				+ "WHERE email = ? ";

		System.out.println(sql);
		PreparedStatement prep = new PostgreSQLAccess().
				getConnection().
				prepareStatement(sql);
		prep.setString(1, passwort);
		prep.setString(2, this.email);
		prep.executeUpdate();
	}
	
	

	public String getVorname() {
		return vorname;
	}


	public void setVorname(String vorname) {
		this.vorname = vorname;
	}


	public String getNachname() {
		return nachname;
	}


	public void setNachname(String nachname) {
		this.nachname = nachname;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getTelefonnummer() {
		return telefonnummer;
	}


	public void setTelefonnummer(String telefonnummer) {
		this.telefonnummer = telefonnummer;
	}


	public String getStrasse() {
		return strasse;
	}


	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}


	public int getHaus_nr() {
		return haus_nr;
	}


	public void setHaus_nr(int haus_nr) {
		this.haus_nr = haus_nr;
	}


	public String getPasswort() {
		return passwort;
	}


	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}


	public String getStadt() {
		return stadt;
	}


	public void setStadt(String stadt) {
		this.stadt = stadt;
	}


	public int getPlz() {
		return plz;
	}


	public void setPlz(int plz) {
		this.plz = plz;
	}


	public String getGeburtsdatum() {
		return geburtsdatum;
	}


	public void setGeburtsdatum(String geburtsdatum) {
		this.geburtsdatum = geburtsdatum;
	}


	public boolean isAngemeldet() {
		return angemeldet;
	}


	public void setAngemeldet(boolean angemeldet) {
		this.angemeldet = angemeldet;
	}


	public String getBestaetigungsCode() {
		return BestaetigungsCode;
	}


	public void setBestaetigungsCode(String bestaetigungsCode) {
		BestaetigungsCode = bestaetigungsCode;
	}

	
	
}
