package praktikumBeans;

import java.util.Random;

public class zufääligeZahl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String chars = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder result = new StringBuilder();
        Random random = new Random();

        // Wähle 4 zufällige Zeichen aus dem code-String
        for (int i = 0; i < 10; i++) {
            int index = random.nextInt(chars.length());
            result.append(chars.charAt(index));
        }
        
        String code = result.toString();
        System.out.println("Die ausgewählten Zeichen: " + code);
	}

}
