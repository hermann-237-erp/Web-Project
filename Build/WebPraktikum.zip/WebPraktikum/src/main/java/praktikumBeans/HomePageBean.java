package praktikumBeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import praktikumWeb.jdbc.NoConnectionException;
import praktikumWeb.jdbc.PostgreSQLAccess;

public class HomePageBean {
	String postleitzahl_stadtteil;
	boolean AngebotSuchenGeklickt;
	boolean homepageBodyZeigen;
	String rubrik ;
	boolean datenSatzInDBgefunden;
	boolean angemeldet;
	String email;
	


	public HomePageBean() {
		rubrik = "";
		postleitzahl_stadtteil="";
		AngebotSuchenGeklickt = false;
		homepageBodyZeigen=true;
		 datenSatzInDBgefunden =false;
		 angemeldet = false;
	}





	public String getAngebot()throws NoConnectionException, SQLException{
		String html ="";
		datenSatzInDBgefunden = false;
	if(AngebotSuchenGeklickt ) {
		homepageBodyZeigen=false;
		  System.out.println("AngebotSuchenGeklickt: "+AngebotSuchenGeklickt);
		String sql = "Select* "
				+ "from angebot  a left join benutzer  b "
				+ "on a.vermirter_email = b.email   "
				+ "where (postleitzahl_stadt = ? or stadtteil = ?) and rubrik = ?";
		System.out.println(sql);
		Connection dbconn = new PostgreSQLAccess().getConnection();
		PreparedStatement prep = dbconn.prepareStatement(sql);
		prep.setString(1, postleitzahl_stadtteil);
		prep.setString(2, postleitzahl_stadtteil);
		prep.setString(3, rubrik);
		
		ResultSet dbRes = prep.executeQuery();
		
			
		while (dbRes.next()) {
			
			datenSatzInDBgefunden = true;
			  String AlleFoto = dbRes.getString("zimmerfoto").trim();
			  String[] arrayFoto = AlleFoto.split(",");
			  String foto = arrayFoto[0].trim();
			   html +=  "<div class=star\n>" 
					    + "<img src=../img/"+ foto+" alt="+dbRes.getString("zimmerfoto").trim()+"\n>"
					    		+ " <input type=hidden  name='angebot_id' value='"+dbRes.getInt("angebot_id")+"'>\n"
					    		+ "" 
					    + "<div>" 
					    +    "<div class=form-group\n>" 
					    +        "<p>"+ dbRes.getString("titel_des_angebots").trim()+"</p>" 
					    +    "</div>" 
					    +    "<div class=\"form-group\">" 
					    +        "<table class=\"ausstattung-table\">" 
					    +            "<tr>" 
					    +                "<td><label>Straße und HausNr</label> "+dbRes.getString("strasse_nr").trim()+"</td>" 
					    +                "<td><label>plz</label> "+dbRes.getString("postleitzahl_stadt").trim() +" "+ dbRes.getString("stadt").trim()+"</td>" 
					    +                "<td><label>Etage</label>"+dbRes.getString("etage").trim()+"</td>" 
					    +            "</tr>" 
					    +            "<tr>" 
					    +                "<td><label>Rubrik</label> "+dbRes.getString("rubrik").trim()+"</td>" 
					    +                "<td><label>Gesuche Geschlecht</label>"+dbRes.getString("gesuche_geschlecht").trim()+"</td>" 
					    +                "<td><label>Miete</label>"+dbRes.getString("gesamtmiete").trim()+"$</td>" 
					    +            "</tr>" 
					    +            "<tr>" 
					    +                "<td><label>Vermieter</label> "+dbRes.getString("vorname").trim()+" "+dbRes.getString("nachname").trim()+"</td>" 
					    +                "<td></td>" 
					    +                "<td><label>online Seit</label>"+dbRes.getDate("angeleget_am")+"</td>" 
					    +            "</tr>"
					    +            "<tr>" 
					    +                "<td></td>" 
					    +                "<td></td>" 
					    +                "<td><input type ='submit' name ='mehrErfahren' value ='mehr erfahren'></td>" 
					    +            "</tr>" 
					    +        "</table>" 
					    +    "</div>" 
					    + "</div>" 
					    + "</div>";
			   
		  }
		
		return html;
	  }else {
		  System.out.println(AngebotSuchenGeklickt);
		  return html;
	  }

	}
	
	public String getDetailHomepage()throws NoConnectionException, SQLException{
		String html ="";
		
		if(homepageBodyZeigen) {
			AngebotSuchenGeklickt = false;
			html += "<section class=\"why-us\">\n" 
				    + "<h2>Warum wir uns abheben</h2>\n"
				    + "<div class=\"features\">\n"
				    + "<div class=\"feature\">\n"
				    + "<div class=\"icon\">\n"
				    + "<i class=\"fa fa-info-circle\"></i>\n"
				    + "</div>\n"
				    + "<h3>Große Auswahl an Zimmern</h3>\n"
				    + "<p>Mein Zimmer Lu bietet eine umfangreiche Auswahl an Zimmern in verschiedenen Städten und Preisklassen. Egal, ob Sie nach einem günstigen Zimmer oder einer luxuriösen Unterkunft suchen, bei uns finden Sie das passende Angebot.</p>\n"
				    + "</div>\n"
				    + "<div class=\"feature\">\n"
				    + "<div class=\"icon\">\n"
				    + "<i class=\"fa fa-search\"></i>\n"
				    + "</div>\n"
				    + "<h3>Benutzerfreundliche Suchfunktion</h3>\n"
				    + "<p>Unsere Webseite ist mit einer benutzerfreundlichen Suchfunktion ausgestattet, die es Ihnen ermöglicht, schnell und unkompliziert das ideale Zimmer zu finden. Filtern Sie Ihre Suche nach Lage, Preis und Ausstattung.</p>\n"
				    + "</div>\n"
				    + "<div class=\"feature\">\n"
				    + "<div class=\"icon\">\n"
				    + "<i class=\"fa fa-headset\"></i>\n"
				    + "</div>\n"
				    + "<h3>Zuverlässiger Kundenservice</h3>\n"
				    + "<p>Bei Mein Zimmer Lu steht der Kunde im Mittelpunkt. Unser engagiertes Support-Team steht Ihnen bei Fragen und Anliegen jederzeit zur Verfügung, um Ihnen ein sorgenfreies Buchungserlebnis zu garantieren.</p>\n"
				    + "</div>\n"
				    + "</div>\n"
				    + "</section>\n"
				    +"<section class=\"services\">\n"
				    + "<h2>Services</h2>\n"
				    + "<p>Entdecken Sie unser Dienstleistungsangebot</p>\n"
				    + "<div class=\"service-container\">\n"
				    + "<div class=\"service\">\n"
				    + "<img src=../img/../img/imagesZimmer.jpeg alt=\"Modernes Zimmer\">\n"
				    + "<div class=\"service-text\">\n"
				    + "<h3>Zimmervermittlung</h3>\n"
				    + "<p>Unsere Plattform bietet eine benutzerfreundliche Oberfläche, um Zimmer in Ihrer bevorzugten Lage zu finden. Mit detaillierten Filtern können Sie genau die Unterkunft auswählen, die Ihren Bedürfnissen entspricht.</p>\n"
				    + "</div>\n"
				    + "</div>\n"
				    + "<div class=\"service\">\n"
				    + "<div class=\"service-text\">\n"
				    + "<h3>Persönliche Beratung</h3>\n"
				    + "<p>Unser engagiertes Team steht Ihnen mit persönlicher Beratung zur Seite, um den perfekten Raum für Sie zu finden. Vertrauen Sie auf unsere Expertise, um die ideale Lösung zu finden.</p>\n"
				    + "</div>\n"
				    + "<img src=../img/bild_a.jpg alt=\"Prüfungsformat\">\n"
				    + "</div>\n"
				    + "</div>\n"
				    + "</section>\n";
			return html;
		}
		else return html;
	}
	
	public String headerTeilKonto(){
		String html ="";
		if (angemeldet) {
			html +=   "<header>\r\n"
					+ "        <div class=\"logo\">\r\n"
					+ "            <a href=\"Appl.jsp?zumStartseite=zumStartseite\">\r\n"
					+ "                <img src=\"../img/Salford & Co..jpg\" alt=\"MeinZimmerLU\">\r\n"
					+ "            </a>\r\n"
					+ "        </div>\r\n"
					+ "        <nav>\r\n"
					+ "            <ul>\r\n"
					+ "                <li><a href=\"HomePage2.jsp\">Zimmer suchen</a></li>\r\n"
					+ "                <li><a href=\"Angebot_InsesierenView.jsp\">Angebot inserieren</a></li>\r\n"
					+ "                <li><a href=\"#\">Über uns</a></li>\r\n"
					+ "            </ul>\r\n"
					+ "        </nav>"
					+" <form action=\"Appl.jsp\" method=\"get\" enctype=\"multipart/form-data\">" 
					+"   <div class=\"konto-dropdown\">\r\n"
					+ "        "+getEmail()+"\r\n"
					+ "            <button class=\"konto-btn\" type=\"submit\" name=\"zumKonto\" value=\"zumKonto\">My Konto</button>"
					+ "            <button class=\"konto-btn\" type=\"submit\" name=\"abmelden\" value=\"abmelden\">abmelden</button>"
					+ "        </div>"
					+ "</form> "
					+ "</header>";
			return html;
			        
		}
		else {
			html +=   "<header>\r\n"
					+ "        <div class=\"logo\">\r\n"
					+ "            <a href=\"Appl.jsp?zumStartseite=zumStartseite\">\r\n"
					+ "                <img src=\"../img/Salford & Co..jpg\" alt=\"MeinZimmerLU\">\r\n"
					+ "            </a>\r\n"
					+ "        </div>\r\n"
					+ "        <nav>\r\n"
					+ "            <ul>\r\n"
					+ "                <li><a href=\"HomePage2.jsp\">Zimmer suchen</a></li>\r\n"
					+ "                <li><a href=\"Angebot_InsesierenView.jsp\">Angebot inserieren</a></li>\r\n"
					+ "                <li><a href=\"#\">Über uns</a></li>\r\n"
					+ "            </ul>\r\n"
					+ "        </nav>"
					+ "   <div class=\"konto-dropdown\">\r\n"
					+ "            <button class=\"konto-btn\">Konto</button>\r\n"
					+ "            <div class=\"dropdown-content\">\r\n"
					+ "                <a href=\"Anmeldung.jsp\">Anmeldung</a>\r\n"
					+ "                <a href=\"RegistrierungsView.jsp\">Registrierung</a>\r\n"
					+ "            </div>\r\n"
					+ "        </div>"
					+ " </header>";
			return html;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public String getPostleitzahl_stadtteil() {
		return postleitzahl_stadtteil;
	}


	public void setPostleitzahl_stadtteil(String postleitzahl_stadtteil) {
		this.postleitzahl_stadtteil = postleitzahl_stadtteil;
	}



	public boolean isAngebotSuchenGeklickt() {
		return AngebotSuchenGeklickt;
	}


	public void setAngebotSuchenGeklickt(boolean angebotSuchenGeklickt) {
		AngebotSuchenGeklickt = angebotSuchenGeklickt;
	}





	public String getRubrik() {
		return rubrik;
	}





	public void setRubrik(String rubrik) {
		this.rubrik = rubrik;
	}





	public boolean isHomepageBodyZeigen() {
		return homepageBodyZeigen;
	}





	public void setHomepageBodyZeigen(boolean homepageBodyZeigen) {
		this.homepageBodyZeigen = homepageBodyZeigen;
	}





	public boolean isDatenSatzInDBgefunden() {
		return datenSatzInDBgefunden;
	}





	public void setDatenSatzInDBgefunden(boolean datenSatzInDBgefunden) {
		this.datenSatzInDBgefunden = datenSatzInDBgefunden;
	}





	public boolean isAngemeldet() {
		return angemeldet;
	}





	public void setAngemeldet(boolean angemeldet) {
		this.angemeldet = angemeldet;
	}





	public String getEmail() {
		return email;
	}





	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
