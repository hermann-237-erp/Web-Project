

package praktikumBeans;

public class messageBeans {
	boolean insertAngebotFehlgeschlagen;
	boolean emailExists;
	boolean emailNichtgefunden;
	String email;
	boolean emailPasswortExists;
	boolean emailUngueltig;
	boolean keinZimmerGefundenMsgAnzeigen;
	boolean angemeldet;
	boolean sendenNachrichtGeklickt;
	boolean zumFavorithinzufuegenGeklickt;
	boolean codeFalsch;
	public messageBeans() {
		// TODO Auto-generated constructor stub
		emailUngueltig = false;
		insertAngebotFehlgeschlagen = false;
		emailExists = false;
		email="";
		emailPasswortExists = true;//Damit bei Aktualisierung von RegistrierungsView.jsp erscheint die fehlerMeldung nicht.
		keinZimmerGefundenMsgAnzeigen =false;
		angemeldet= false;
		sendenNachrichtGeklickt = false;
		zumFavorithinzufuegenGeklickt = false;
		emailNichtgefunden = false;
		 codeFalsch=false;

		
	}

	public String getMessageEmailExist() { //Registrierung fehlgeschlagen 
		
		if (emailExists) {
			emailExists = false; //Damit bei Aktualisierung von RegistrierungsView.jsp erscheint die fehlerMeldung nicht.
			return "Ein Benutzer mit der Email " +email+ " existiert bereit ";
		}else if (emailUngueltig) {
			emailUngueltig = false; //Damit bei Aktualisierung von RegistrierungsView.jsp erscheint die fehlerMeldung nicht.
			return "Der Email " +email+ " ist ungultig ";
		}else 
			return " ";
	}
	
	public String getMessageKeinZimmerGefunden() {
		String html="";
		if(keinZimmerGefundenMsgAnzeigen) {
		html +=  "für diese Suche wurde nichts gefunden";
		}
		return html;
	}
	
	public String FavoriteInDBMessage() {
		String html="";
		 if(angemeldet && zumFavorithinzufuegenGeklickt) {
				html += "<div id=\"fehlermeldung\" style=\"display: block; text-align: center; color: green; margin: 10px 0;\">\r\n"
					  + "    es wurde erfolgreich zum Favorit hinzugefügt\r\n"
					  + "</div>";
				zumFavorithinzufuegenGeklickt=false;
			}
			else if(!(angemeldet) && zumFavorithinzufuegenGeklickt){
				html+="<div id=\"fehlermeldung\" style=\"display: block; text-align: center; color: red; margin: 10px 0;\">\r\n"
						+ "  Bitte melden Sie sich erstmal an \r\n"
						+ "</div>";
				zumFavorithinzufuegenGeklickt= false;
			}
			return html;
	}
	
	public String kontaktVermieterMsg() {
		String html="";
		if(angemeldet && sendenNachrichtGeklickt) {
		html +=  "<div id=\"fehlermeldung\" style=\"display: block; text-align: center; color: green; margin: 10px 0;\">\r\n"
				+ "    Ihre Nachricht wurde erfolgreich gesendet\r\n"
				+ "</div>";
		sendenNachrichtGeklickt= false;
		}
		else if(!(angemeldet) && sendenNachrichtGeklickt){
			html+="<div id=\"fehlermeldung\" style=\"display: block; text-align: center; color: blue; margin: 10px 0;\">\r\n"
					+ "  Bitte melden Sie sich erstmal an \r\n"
					+ "</div>";
			sendenNachrichtGeklickt= false;
		}
		return html;
	
	}
	
public String getMessageLogingFehlgeschlagen() { //Registrierung fehlgeschlagen 
	String html = "";
		if (emailPasswortExists) {
			return " ";
		}else {
			
			emailPasswortExists = true;//Damit bei Aktualisierung von ameldung.jsp erscheint die fehlerMeldung nicht.
			html += "<h3>Email oder Passwort falsch</h3>\n";
			html += "<h4>Bitte versuchen Sie es noch einmal</h4>\n";
			return html;
		}
	}
public String getMessageEmailNichtGefunden() { //Registrierung fehlgeschlagen 
	String html = "";
		if (!emailNichtgefunden) {
			return "";
		}else {		emailNichtgefunden = false;//Damit bei Aktualisierung erscheint die fehlerMeldung nicht.
			html += "<h3>Email nicht gefunden</h3>\n";
			return html;
		}
	}
	
public String getinsertAngebotFehlgeschlagenMsg() { //Registrierung fehlgeschlagen 
		if (insertAngebotFehlgeschlagen) {
			insertAngebotFehlgeschlagen = false;//Damit bei Aktualisierung von Angebot_InsesierenView.jsp erscheint die fehlerMeldung nicht.
			return "<h5>um ein Angebot zu insesieren Sie müssen angemeldet werden</h5>\n";
		}else {
			return " ";
		}
	}
	
public String getCodeFalschMsg() {
	String html = "";
	if (!codeFalsch) {
		return "";
	}else {		codeFalsch = false;//Damit bei Aktualisierung erscheint die fehlerMeldung nicht.
		html += "<h3>Der eingebene Code stimmt nicht überheim</h3>\n";
		return html;
	}
}

	public boolean isEmailExists() {
		return emailExists;
	}

	public void setEmailExists(boolean emailExists) {
		this.emailExists = emailExists;
		System.out.println(" " + this.emailExists + " geSet");
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isEmailPasswortExists() {
		return emailPasswortExists;
	}

	public void setEmailPasswortExists(boolean emailPasswortExists) {
		this.emailPasswortExists = emailPasswortExists;
	}

	public boolean isinsertAngebotFehlgeschlagen() {
		return insertAngebotFehlgeschlagen;
	}

	public void setInsertAngebotFehlgeschlagen(boolean insertAngebotFehlgeschlagen) {
		this.insertAngebotFehlgeschlagen = insertAngebotFehlgeschlagen;
	}

	public boolean isEmailUngueltig() {
		return emailUngueltig;
	}

	public void setEmailUngueltig(boolean emailUngueltig) {
		this.emailUngueltig = emailUngueltig;
	}

	public boolean isKeinZimmerGefundenMsgAnzeigen() {
		return keinZimmerGefundenMsgAnzeigen;
	}

	public void setKeinZimmerGefundenMsgAnzeigen(boolean datenSatzInDBgefunden) {
		this.keinZimmerGefundenMsgAnzeigen = datenSatzInDBgefunden;
	}

	public boolean isAngemeldet() {
		return angemeldet;
	}

	public void setAngemeldet(boolean angemeldet) {
		this.angemeldet = angemeldet;
	}

	public boolean isSendenNachrichtGeklickt() {
		return sendenNachrichtGeklickt;
	}

	public void setSendenNachrichtGeklickt(boolean sendenNachrichtGeklickt) {
		this.sendenNachrichtGeklickt = sendenNachrichtGeklickt;
	}

	public boolean isInsertAngebotFehlgeschlagen() {
		return insertAngebotFehlgeschlagen;
	}

	public boolean isZumFavorithinzufuegenGeklickt() {
		return zumFavorithinzufuegenGeklickt;
	}

	public void setZumFavorithinzufuegenGeklickt(boolean zumFavorithinzufuegenGeklickt) {
		this.zumFavorithinzufuegenGeklickt = zumFavorithinzufuegenGeklickt;
	}

	public boolean isEmailNichtgefunden() {
		return emailNichtgefunden;
	}

	public void setEmailNichtgefunden(boolean emailNichtgefunden) {
		this.emailNichtgefunden = emailNichtgefunden;
	}

	public boolean isCodeFalsch() {
		return codeFalsch;
	}

	public void setCodeFalsch(boolean codeFalsch) {
		this.codeFalsch = codeFalsch;
	}
	
	
}
