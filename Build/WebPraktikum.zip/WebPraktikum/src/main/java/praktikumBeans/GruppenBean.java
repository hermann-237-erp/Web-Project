package praktikumBeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import praktikumWeb.jdbc.NoConnectionException;
import praktikumWeb.jdbc.PostgreSQLAccess;

//import de.hwg_lu.bwi420.klausurW23beans.NoConnectionException;
//import de.hwg_lu.bwi420.klausurW23beans.PostgreSQLAccess;

public class GruppenBean {
	
	String tname ;
	String email;
	String gruppenname;
	
	public  GruppenBean() {
		
		this.tname = "";
		this.email = "";
		this.gruppenname = "";
	}
	
	public void insertteilnehmer() throws NoConnectionException, SQLException {
		
		String sql= "insert into teilnehmer (tname, email, gruppenname)		values (?,?,?) ";
		Connection dbConn = new PostgreSQLAccess().getConnection();
		PreparedStatement prep = dbConn.prepareStatement(sql);
		prep.setString(1, this.tname);
		prep.setString(2, this.email);
		prep.setString(3, this.gruppenname);
		prep.executeUpdate();
		System.out.println("Teilnehmer  erfolgreich angelegt");
	}
	
	
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGruppenname() {
		return gruppenname;
	}
	public void setGruppenname(String gruppenname) {
		this.gruppenname = gruppenname;
	}
	

}
