package praktikumBeans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import praktikumWeb.jdbc.NoConnectionException;
import praktikumWeb.jdbc.PostgreSQLAccess;

public class AngebotInsesierenBean {
	
	String vermirter_email;	
	String angebotTitle ;
    String stadt ;
    String rubrik ;
    String stadtteil;
    String strasse_Nr ;
    String postleitzahl ;
    String verfuegbarAb ;
    String verfuegbarBis ;
    String etage ;
    String zimmergroesse ;
    String wohnungsgroesse ;
  //String groesse ;
    String zimmeranzahl ;
    String kaltmiete ;
    String nebenkosten ;
    String miete ;
    String kaution ;
    String[] ausstattung ;
    String beschreibung ;
	String sprache;
	String zimmerfoto;
    String[] gesuche_geschlecht;
	int angebot_id;
	 
	String postleitzahl_stadtteil;
	boolean AngebotSuchenGeklickt;
	
	String vermieterVorname;
	String vermieterNachname;
	int angebotId;
	 
	public AngebotInsesierenBean() {
		zimmerfoto = "";
		angebotTitle = "";
		stadt = "";
		rubrik = "";
	//	mietart = "";
		stadtteil = "";
		strasse_Nr = "";
		postleitzahl = "";
		verfuegbarAb = "";
		verfuegbarBis = "";
		etage = "";
		zimmergroesse = "";
		wohnungsgroesse = "";
	//	groesse = "";
		zimmeranzahl = "";
		kaltmiete = "";
		nebenkosten = "";
		miete = "";
		sprache= "";
		kaution = "";
		ausstattung = new String[0]; 
		beschreibung = "";
		vermirter_email = "";
		gesuche_geschlecht = new String[0];
		
		angebot_id=0;
		
		postleitzahl_stadtteil="";
		AngebotSuchenGeklickt = false;
		
		vermieterVorname="";
		vermieterNachname="";
	}
	
	
	
	
	public void insertAngebot() throws NoConnectionException, SQLException{
		
		String ausstattung = String.join(",", this.ausstattung);
		String gesuche_geschlecht = String.join(",", this.gesuche_geschlecht);
		

		
		String sql = "INSERT INTO angebot "
		           + "(vermirter_email, titel_des_angebots, stadt, rubrik, stadtteil, strasse_Nr, postleitzahl_Stadt, "
		           + "verfuegbar_ab, verfuegbar_bis, etage, zimmergroesse, wohnungsgroesse, zimmer_anzahl, kaltmiete, "
		           + "nebenkosten, gesamtmiete, kaution, ausstattung, beschreibung, sprache,gesuche_geschlecht,zimmerfoto) "
		           + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,  ?, ?,?)";

		System.out.println(sql);

		// Establish a connection to the database
		Connection dbConn = new PostgreSQLAccess().getConnection();

		// Prepare the statement with the new SQL
		PreparedStatement prep = dbConn.prepareStatement(sql);

		// Set the variables with the corresponding data types
		prep.setString(1, this.vermirter_email);
		prep.setString(2, this.angebotTitle);
		prep.setString(3, this.stadt);
		prep.setString(4, this.rubrik);
		prep.setString(5, this.stadtteil);
		prep.setString(6, this.strasse_Nr);
		prep.setString(7, this.postleitzahl);
		prep.setString(8, this.verfuegbarAb);
		prep.setString(9, this.verfuegbarBis);
		prep.setString(10, this.etage);
		prep.setString(11, this.zimmergroesse);
		prep.setString(12, this.wohnungsgroesse);
	//	prep.setString(13, this.groesse);
		prep.setString(13, this.zimmeranzahl);
		prep.setString(14, this.kaltmiete);
		prep.setString(15, this.nebenkosten);
		prep.setString(16, this.miete);
		prep.setString(17, this.kaution);
		prep.setString(18, ausstattung);
		prep.setString(19, this.beschreibung);
		prep.setString(20, this.sprache);
		prep.setString(21, gesuche_geschlecht);
		prep.setString(22, zimmerfoto);

		// Execute the update to insert the data
		prep.executeUpdate();

		System.out.println("Eintrag erfolgreich angelegt");
	}
	
	public String getAngebot()throws NoConnectionException, SQLException{
		String html ="";
		
	if(AngebotSuchenGeklickt) {
		  System.out.println("AngebotSuchenGeklickt: "+AngebotSuchenGeklickt);
		String sql = "Select* "
				+ "from angebot  a left join benutzer  b "
				+ "on a.vermirter_email = b.email   "
				+ "where (postleitzahl_stadt = ? or stadtteil = ?) and rubrik = ?";
		System.out.println(sql);
		Connection dbconn = new PostgreSQLAccess().getConnection();
		PreparedStatement prep = dbconn.prepareStatement(sql);
		prep.setString(1, postleitzahl_stadtteil);
		prep.setString(2, postleitzahl_stadtteil);
		prep.setString(3, rubrik);
		
		ResultSet dbRes = prep.executeQuery();
		boolean datenSatzInDBgefunden =false;
		while (dbRes.next()) {
			datenSatzInDBgefunden = true;
			  System.out.println("Habe while");
			  String AlleFoto = dbRes.getString("zimmerfoto").trim();
			  String[] arrayFoto = AlleFoto.split(",");
			  String foto = arrayFoto[0].trim();
			   html +=  "<div class=star\n>" 
					    + "<img src=../img/"+ foto+" alt="+dbRes.getString("zimmerfoto").trim()+"\n>"
					    		+ " <input type=hidden  name='angebot_id' value='"+dbRes.getInt("angebot_id")+"'>\n"
					    		+ "" 
					    + "<div>" 
					    +    "<div class=form-group\n>" 
					    +        "<p>"+ dbRes.getString("titel_des_angebots").trim()+"</p>" 
					    +    "</div>" 
					    +    "<div class=\"form-group\">" 
					    +        "<table class=\"ausstattung-table\">" 
					    +            "<tr>" 
					    +                "<td><label>Straße und HausNr</label> "+dbRes.getString("strasse_nr").trim()+"</td>" 
					    +                "<td><label>plz</label> "+dbRes.getString("postleitzahl_stadt").trim() +" "+ dbRes.getString("stadt").trim()+"</td>" 
					    +                "<td><label>Etage</label>"+dbRes.getString("etage").trim()+"</td>" 
					    +            "</tr>" 
					    +            "<tr>" 
					    +                "<td><label>Rubrik</label> "+dbRes.getString("rubrik").trim()+"</td>" 
					    +                "<td><label>Gesuche Geschlecht</label>"+dbRes.getString("gesuche_geschlecht").trim()+"</td>" 
					    +                "<td><label>Miete</label>"+dbRes.getString("gesamtmiete").trim()+"$</td>" 
					    +            "</tr>" 
					    +            "<tr>" 
					    +                "<td><label>Vermieter</label> "+dbRes.getString("vorname").trim()+" "+dbRes.getString("nachname").trim()+"</td>" 
					    +                "<td></td>" 
					    +                "<td><label>online Seit</label>"+dbRes.getDate("angeleget_am")+"</td>" 
					    +            "</tr>"
					    +            "<tr>" 
					    +                "<td></td>" 
					    +                "<td></td>" 
					    +                "<td><input type ='submit' name ='mehrSehen' value ='mehr Sehen'></td>" 
					    +            "</tr>" 
					    +        "</table>" 
					    +    "</div>" 
					    + "</div>" 
					    + "</div>";
			   
		  }
		
		AngebotSuchenGeklickt=false;
		if(datenSatzInDBgefunden) return html;
		else { html +=     "<div id='fehlermeldung' style='block: flex; text-align: center; color: red; margin: 10px 0;'>"
						+	 "für diese Suche wurde nichts gefunden"
						+ "</div>";

		  
		return html;
		}
		
	  }else {
		  System.out.println(AngebotSuchenGeklickt);
		  return html;
	  }

	}
	
	
	public String detailZumAngebot() throws NoConnectionException, SQLException{
		String html ="";
		String sql = "Select* "
				+ "from angebot  a left join benutzer  b "
				+ "on a.vermirter_email = b.email   "
				+ "where angebot_id = ?" ;
		Connection dbconn = new PostgreSQLAccess().getConnection();
		PreparedStatement prep = dbconn.prepareStatement(sql);
		prep.setInt(1, angebot_id);
		ResultSet dbRes = prep.executeQuery();
		
		while (dbRes.next()) {
			vermieterVorname = dbRes.getString("vorname").trim();
			vermieterNachname = dbRes.getString("nachname").trim();
			vermirter_email = dbRes.getString("vermirter_email").trim();
			angebot_id = dbRes.getInt("angebot_id");
			  String AlleFoto = dbRes.getString("zimmerfoto").trim();
			  String[] arrayFoto = AlleFoto.split(",");
			  html +="	   <div class=\"slideshow-container\">";
			  for(int i =0; i<arrayFoto.length; i++ ) {
			 html += 		"	<div class=\"mySlides fade\">\r\n"
				  + "			  <div class=\"numbertext\">"+(i+1)+" /"+arrayFoto.length+"</div>\r\n"
				  + "			  <img src=\"../img/"+arrayFoto[i]+"\" style=\"width:100%; height: 300px\">\r\n"
				  + "	        </div>";
				  		
			  }
			  html +="      <a class=\"prev\" onclick=\"plusSlides(-1)\"> < </a>\r\n"
				   + "		<a class=\"next\" onclick=\"plusSlides(1)\">  > </a>\r\n"	 
				   + "	   </div>\r\n"
				   + "	<br>"
				   + "<div style=\"text-align:center\">";
			  
			  for(int i =0; i<arrayFoto.length; i++ ) {
			  html +="    <span class=\"dot\" onclick=\"currentSlide("+(i+1)+")\"></span> ";
			  }
			  html +=" </div>";
			  
			  html +="<div class=\"form-group\">\r\n"
			  		+ "		            <div >"+dbRes.getString("titel_des_angebots").trim()+"</div>\r\n"
			  		+ "		 </div>\r\n"
			  		+ "		 <br>\r\n"
			  		+ "		  <div class=\"form-row\">\r\n"
			  		+ "	           <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"Rübrik\">Rübrik</label>"+dbRes.getString("rubrik").trim()+"\r\n"
			  		+ "	           </div>\r\n"
			  		+ "	           <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"Etage\">Etage</label>"+dbRes.getString("etage").trim()+"\r\n"
			  		+ "	           </div>\r\n"
			  		+ "	            <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"zimmergroesse\">zimmergroesse</label>"+dbRes.getString("zimmergroesse").trim()+"m²\r\n"
			  		+ "	           </div>      \r\n"
			  		+ "		  </div>\r\n"
			  		+ "		  <div class=\"form-row\">\r\n"
			  		+ "	           <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"Kaltmiete\">Kaltmiete</label>"+dbRes.getString("kaltmiete").trim()+"\r\n"
			  		+ "	           </div>\r\n"
			  		+ "	           <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"Nebenkosten\">Nebenkosten</label>"+dbRes.getString("nebenkosten").trim()+"\r\n"
			  		+ "	           </div>\r\n"
			  		+ "	            <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"Gesamtmiete\">Gesamtmiete</label>"+dbRes.getString("gesamtmiete").trim()+"\r\n"
			  		+ "	           </div>      \r\n"
			  		+ "		  </div>\r\n"
			  		+ "		  <div class=\"form-row\">\r\n"
			  		+ "	           <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"Verfügbar ab\">Verfügbar ab</label>"+dbRes.getString("verfuegbar_ab")+"\r\n"
			  		+ "	           </div>\r\n"
			  		+ "	           <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"Verfügbar ab\">Verfügbar bis</label>"+dbRes.getString("verfuegbar_bis")+"\r\n"
			  		+ "	           </div>\r\n"
			  		+ "	            <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"angeleget am\">angeleget am</label>"+dbRes.getDate("angeleget_am")+"\r\n"
			  		+ "	           </div>      \r\n"
			  		+ "		  </div>\r\n"
			  		+ "		  <div class=\"form-row\">\r\n"
			  		+ "	           <div class=\"form-group\">\r\n"
			  		+ "	           	<label for=\"Adresse\">Adresse</label>"+dbRes.getString("strasse_Nr").trim()+"<br>"+dbRes.getString("postleitzahl_Stadt").trim()+"\r\n"
			  		+ "	           </div>\r\n"
			  		+ "    \r\n"
			  		+ "		  </div>\r\n"
			  		+ "		  <div class=\"form-row\">\r\n"
			  		+ "	           <div class=\"form-group\">\r\n"
			  		+ "		           	<label for=\"Ausstatung\">Ausstatung</label>\r\n";
			  
			  String ausstatungenStr = dbRes.getString("ausstattung").trim();
			  String[] ausstattungen = ausstatungenStr.split(",");
			  		
			  		for(String ausstatung: ausstattungen) {
			   html += "		    	<div>"+ausstatung+"</div>";
			  		
			  		}
			   html += "</div>\r\n"
			   		+ "	            <div class=\"form-group\">\r\n"
			   		+ "	            	<label for=\"weitere\">Weitere Angabe</label>\r\n"
			   		+ "	            		<div>gesuche Geschlecht: "+dbRes.getString("gesuche_geschlecht").trim()+"</div>\r\n"
			   		+ "		           	<div>geprochene sprache: "+dbRes.getString("sprache").trim()+"</div>\r\n"
			   		+ "		           	<div> zimmer_anzahl: "+dbRes.getString("zimmer_anzahl").trim()+"</div>\r\n"
			   		+ "	            </div>\r\n"
			   		+ "		  </div>\r\n"
			   		+ "</div>";

		}
		
		return html;
	}
	
	public boolean sendMessage( String betreff, String nachricht ) {
	        String html ="";
	        
	        html +="Betreff: "+betreff+"(Angebot Id: "+angebot_id+")\n"
        		 + nachricht;
		 		 
	        
			JavaMail javaMail = new JavaMail();
			javaMail.setEmpfaenger(vermirter_email);
			javaMail.setBetreff(betreff);
			javaMail.setNachricht(html);
			System.out.println(html);
			return javaMail.sendEmail();
		}
	
	public void kontaktiertesAngobotSpeichern(String interessierte_Email, String nachricht) throws NoConnectionException, SQLException {
		String sql = "INSERT INTO message "
		           + "(angebot_id, nachricht, interessierte, vermieter) "
		           + "VALUES (?, ?, ?, ?)";

		System.out.println(sql);
		PreparedStatement prep = new PostgreSQLAccess().
				getConnection().
				prepareStatement(sql);
		prep.setInt(1, this.angebot_id);
		prep.setString(2, nachricht);
		prep.setString(3, interessierte_Email);
		prep.setString(4, this.vermirter_email);
		prep.executeUpdate();
		System.out.println("Erfolgreich im DB gespeichert");
	}
	
	public void favorisInDbSpeichern(String user_email) throws NoConnectionException, SQLException {
		String sql = "INSERT INTO favoris "
		           + "(user_id, angebot_id) "
		           + "VALUES (?, ?)";

		System.out.println(sql);
		PreparedStatement prep = new PostgreSQLAccess().
				getConnection().
				prepareStatement(sql);

		prep.setString(1, user_email);
		prep.setInt(2, this.angebot_id);
		prep.executeUpdate();
		System.out.println("Favoris Erfolgreich im DB gespeichert");
	}
	
	
	
	
	
	

	public String getSprache() {
		return sprache;
	}

	public void setSprache(String sprache) {
		this.sprache = sprache;
	}
	public String getAngebotTitle() {
		return angebotTitle;
	}

	public void setAngebotTitle(String angebotTitle) {
		this.angebotTitle = angebotTitle;
	}

	public String getStadt() {
		return stadt;
	}

	public void setStadt(String stadt) {
		this.stadt = stadt;
	}

	public String getRubrik() {
		return rubrik;
	}

	public void setRubrik(String rubrik) {
		this.rubrik = rubrik;
	}

//	public String getMietart() {
//		return mietart;
//	}

//	public void setMietart(String mietart) {
//		this.mietart = mietart;
//	}

	public String getStadtteil() {
		return stadtteil;
	}

	public void setStadtteil(String stadtteil) {
		this.stadtteil = stadtteil;
	}

	public String getStrasse_Nr() {
		return strasse_Nr;
	}

	public void setStrasse_Nr(String strasse_Nr) {
		this.strasse_Nr = strasse_Nr;
	}

	public String getPostleitzahl() {
		return postleitzahl;
	}

	public void setPostleitzahl(String postleitzahl) {
		this.postleitzahl = postleitzahl;
	}

	public String getVerfuegbarAb() {
		return verfuegbarAb;
	}

	public void setVerfuegbarAb(String verfuegbarAb) {
		this.verfuegbarAb = verfuegbarAb;
	}

	public String getVerfuegbarBis() {
		return verfuegbarBis;
	}

	public void setVerfuegbarBis(String verfuegbarBis) {
		this.verfuegbarBis = verfuegbarBis;
	}

	public String getEtage() {
		return etage;
	}

	public void setEtage(String etage) {
		this.etage = etage;
	}

	public String getZimmergroesse() {
		return zimmergroesse;
	}

	public void setZimmergroesse(String zimmergroesse) {
		this.zimmergroesse = zimmergroesse;
	}

	public String getWohnungsgroesse() {
		return wohnungsgroesse;
	}

	public void setWohnungsgroesse(String wohnungsgroesse) {
		this.wohnungsgroesse = wohnungsgroesse;
	}

//	public String getGroesse() {
//		return groesse;
//	}
//
//	public void setGroesse(String groesse) {
//		this.groesse = groesse;
//	}

	public String getZimmeranzahl() {
		return zimmeranzahl;
	}

	public void setZimmeranzahl(String zimmeranzahl) {
		this.zimmeranzahl = zimmeranzahl;
	}

	public String getKaltmiete() {
		return kaltmiete;
	}

	public void setKaltmiete(String kaltmiete) {
		this.kaltmiete = kaltmiete;
	}

	public String getNebenkosten() {
		return nebenkosten;
	}

	public void setNebenkosten(String nebenkosten) {
		this.nebenkosten = nebenkosten;
	}

	public String getMiete() {
		return miete;
	}

	public void setMiete(String miete) {
		this.miete = miete;
	}

	public String getKaution() {
		return kaution;
	}

	public void setKaution(String kaution) {
		this.kaution = kaution;
	}

	public String[] getAusstattung() {
		return ausstattung;
	}

	public void setAusstattung(String[] ausstattung) {
		this.ausstattung = ausstattung;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public String getVermirter_email() {
		return vermirter_email;
	}

	public void setVermirter_email(String vermirter_email) {
		this.vermirter_email = vermirter_email;
	}

	public String[] getGesuche_geschlecht() {
		return gesuche_geschlecht;
	}

	public void setGesuche_geschlecht(String[] gesuche_geschlecht) {
		this.gesuche_geschlecht = gesuche_geschlecht;
	}

	public String getZimmerfoto() {
		return zimmerfoto;
	}

	public void setZimmerfoto(String zimmerfoto) {
		this.zimmerfoto = zimmerfoto;
	}

	public String getPostleitzahl_stadtteil() {
		return postleitzahl_stadtteil;
	}

	public void setPostleitzahl_stadtteil(String postleitzahl_stadtteil) {
		this.postleitzahl_stadtteil = postleitzahl_stadtteil;
	}

	public boolean isAngebotSuchenGeklickt() {
		return AngebotSuchenGeklickt;
	}

	public void setAngebotSuchenGeklickt(boolean angebotSuchenGeklickt) {
		AngebotSuchenGeklickt = angebotSuchenGeklickt;
	}
	public int getAngebot_id() {
		return angebot_id;
	}

	public void setAngebot_id(int angebot_id) {
		this.angebot_id = angebot_id;
	}

	public String getVermieterVorname() {
		return vermieterVorname;
	}

	public void setVermieterVorname(String vermieterVorname) {
		this.vermieterVorname = vermieterVorname;
	}

	public String getVermieterNachname() {
		return vermieterNachname;
	}

	public void setVermieterNachname(String vermieterNachname) {
		this.vermieterNachname = vermieterNachname;
	}

	public int getAngebotId() {
		return angebotId;
	}

	public void setAngebotId(int angebotId) {
		this.angebotId = angebotId;
	}
	
	
	
}
