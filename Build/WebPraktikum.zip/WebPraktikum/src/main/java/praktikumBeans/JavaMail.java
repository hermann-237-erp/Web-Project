package praktikumBeans;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class JavaMail {

	final String myAccount = "praktikumweb@gmx.net";
	final String myPassword = "praktikumweb&1";// Remplace par ton mot de passe GMX

	//final String myAccount = "praktikumw@gmail.com";
	//final String myPassword = "jcaq siuq zvwy nhts";
	String empfaenger;
	String betreff;
	String nachricht;
	
	public JavaMail() {
		
	}
	
	public boolean sendEmail() {
		Properties properties = new Properties();
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", "smtp.gmx.net");
		properties.put("mail.smtp.port", "587");
		
		/* Anonyme Klasse für Objekterzeugung. */
		Session session = Session.getInstance(properties, new Authenticator() {  
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(myAccount, myPassword);
			}
		});
		
		/* Versuch der Uebersendung der E-Mail. */
		try {
			Message message = prepareMessage(session, myAccount, empfaenger);
			Transport.send(message);
			System.out.println("E-Mail erfolgreich versendet!");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("E-Mail nicht versendet!");
			return false;
		}
	}
	
	/* E-Mail-Message erzeugen. */
	private Message prepareMessage(Session session, String myAccount, String empfaenger) throws AddressException, MessagingException {
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(myAccount));
		message.setRecipient(Message.RecipientType.TO, new InternetAddress(empfaenger));
		message.setSubject(this.betreff);
		
		Multipart multipart = new MimeMultipart();
		BodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setText(this.nachricht);
		multipart.addBodyPart(messageBodyPart);
		message.setContent(multipart);
		
		return message;
	}
	
	public String getEmpfaenger() {
		return empfaenger;
	}

	public void setEmpfaenger(String empfaenger) {
		this.empfaenger = empfaenger;
	}

	public String getBetreff() {
		return betreff;
	}

	public void setBetreff(String betreff) {
		this.betreff = betreff;
	}

	public String getNachricht() {
		return nachricht;
	}

	public void setNachricht(String nachricht) {
		this.nachricht = nachricht;
	}

}