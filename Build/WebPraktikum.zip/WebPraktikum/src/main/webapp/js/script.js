/**
 * 
 */// Funktion, um die Fehlermeldung anzuzeigen und dann nach 5 Sekunden auszublenden
function showFehlermeldung() {
    var fehlermeldung = document.getElementById("fehlermeldung");
		fehlermeldung.style.display = "block";
    // Timeout, um die Fehlermeldung nach 5 Sekunden auszublenden
    setTimeout(function() {
        fehlermeldung.style.display = "none";
    }, 5000);
}



// Funktion, die beim Laden der Seite aufgerufen wird
window.onload = function() {
    showFehlermeldung();
};
