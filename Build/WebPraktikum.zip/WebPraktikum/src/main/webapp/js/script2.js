/**
 * 
 */
document.addEventListener("DOMContentLoaded", function() {
    const ctaButton = document.querySelector(".cta-btn");
    console.log("Seite geladen!");
    ctaButton.addEventListener("click", function() {
        alert("Starte deine Suche nach dem perfekten Zimmer!");
    });
});