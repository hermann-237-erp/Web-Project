// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Select both sections and the links
    const angebotSuchenSection = document.getElementById('angebotSuchen');
    const angebotInsesierenSection = document.getElementById('AngebotInsesieren');
    const angebotSuchenLink = document.getElementById('angebotSuchenLink');
    const angebotInsesierenLink = document.getElementById('angebotInsesierenLink');

    // Initially show the Angebot Suchen section
    angebotSuchenSection.style.display = 'block';

    // Add click event listener for AngebotSuchen
    angebotSuchenLink.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent the default link behavior
        angebotSuchenSection.style.display = 'block';
        angebotInsesierenSection.style.display = 'none';
    });

    // Add click event listener for AngebotInsesieren
    angebotInsesierenLink.addEventListener('click', function(e) {
        e.preventDefault();
        angebotSuchenSection.style.display = 'none';
        angebotInsesierenSection.style.display = 'block';
    });
});
